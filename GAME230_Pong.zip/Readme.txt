Mouse to control the left peddle
Arrow key to control the right peddle

Press space bar to increase time scale


