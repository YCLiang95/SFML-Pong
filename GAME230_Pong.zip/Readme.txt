For some reason I was unable to load any file, either font or sound file
It throws an read access violation, and the console output random things, I tried using search online as well as using absoult path, neither worked
The code for print text and playing sound is currently commented out

Mouse to control the left peddle
Arrow key to control the right peddle


